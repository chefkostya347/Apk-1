package ru.kniznica.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

internal data class PasswordEntry(
    val id: String = newId(),
    val title: String = "",
    val login: String = "",
    val password: String = "",
    val website: String = "",
    val note: String = ""
)

internal data class SavedLink(
    val id: String = newId(),
    val title: String = "",
    val url: String = "",
    val note: String = ""
)

internal data class CalendarNote(
    val id: String = newId(),
    val date: String = "",
    val title: String = "",
    val body: String = ""
)

internal data class VaultData(
    val passwords: List<PasswordEntry> = emptyList(),
    val links: List<SavedLink> = emptyList(),
    val notes: List<CalendarNote> = emptyList()
)

/** Session key exists only in memory while the vault is unlocked. */
internal data class VaultSession(
    val key: SecretKey,
    val salt: ByteArray,
    val data: VaultData
)

internal class VaultStore(context: Context) {
    private val vaultFile = File(context.filesDir, "encrypted-vault.bin")
    private val random = SecureRandom()
    private val magic = "KNZ1".toByteArray(StandardCharsets.US_ASCII)
    private val saltSize = 16
    private val ivSize = 12
    private val tagSizeBits = 128
    private val iterations = 310_000

    fun exists(): Boolean = vaultFile.isFile && vaultFile.length() > 0

    fun create(masterPassword: String): VaultSession {
        check(!exists()) { "Vault already exists" }
        val salt = ByteArray(saltSize).also(random::nextBytes)
        val key = deriveKey(masterPassword, salt)
        val session = VaultSession(key, salt, VaultData())
        writeVault(session.salt, session.key, session.data)
        return session
    }

    fun unlock(masterPassword: String): VaultSession {
        val bytes = vaultFile.readBytes()
        val minSize = magic.size + saltSize + ivSize + 16
        if (bytes.size < minSize || !bytes.copyOfRange(0, magic.size).contentEquals(magic)) {
            throw IOException("Vault format is invalid")
        }
        var offset = magic.size
        val salt = bytes.copyOfRange(offset, offset + saltSize)
        offset += saltSize
        val iv = bytes.copyOfRange(offset, offset + ivSize)
        offset += ivSize
        val ciphertext = bytes.copyOfRange(offset, bytes.size)
        val key = deriveKey(masterPassword, salt)
        val plaintext = try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(tagSizeBits, iv))
            cipher.doFinal(ciphertext)
        } catch (e: AEADBadTagException) {
            throw SecurityException("Wrong master password or damaged vault", e)
        }
        val data = decodeData(String(plaintext, StandardCharsets.UTF_8))
        return VaultSession(key, salt, data)
    }

    fun save(session: VaultSession, data: VaultData): VaultSession {
        writeVault(session.salt, session.key, data)
        return session.copy(data = data)
    }

    private fun deriveKey(password: String, salt: ByteArray): SecretKey {
        val chars = password.toCharArray()
        val spec = PBEKeySpec(chars, salt, iterations, 256)
        return try {
            val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec).encoded
            SecretKeySpec(raw, "AES").also { raw.fill(0) }
        } finally {
            spec.clearPassword()
            chars.fill('\u0000')
        }
    }

    private fun writeVault(salt: ByteArray, key: SecretKey, data: VaultData) {
        val iv = ByteArray(ivSize).also(random::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(tagSizeBits, iv))
        val ciphertext = cipher.doFinal(encodeData(data).toByteArray(StandardCharsets.UTF_8))
        val fileBytes = magic + salt + iv + ciphertext
        val tempFile = File(vaultFile.parentFile, "encrypted-vault.tmp")
        FileOutputStream(tempFile).use { stream ->
            stream.write(fileBytes)
            stream.fd.sync()
        }
        if (!tempFile.renameTo(vaultFile)) {
            tempFile.delete()
            throw IOException("Could not save encrypted vault")
        }
    }

    private fun encodeData(data: VaultData): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("passwords", JSONArray().apply {
            data.passwords.forEach { p ->
                put(JSONObject()
                    .put("id", p.id)
                    .put("title", p.title)
                    .put("login", p.login)
                    .put("password", p.password)
                    .put("website", p.website)
                    .put("note", p.note))
            }
        })
        root.put("links", JSONArray().apply {
            data.links.forEach { link ->
                put(JSONObject()
                    .put("id", link.id)
                    .put("title", link.title)
                    .put("url", link.url)
                    .put("note", link.note))
            }
        })
        root.put("notes", JSONArray().apply {
            data.notes.forEach { note ->
                put(JSONObject()
                    .put("id", note.id)
                    .put("date", note.date)
                    .put("title", note.title)
                    .put("body", note.body))
            }
        })
        return root.toString()
    }

    private fun decodeData(json: String): VaultData {
        val root = JSONObject(json)
        val passwords = buildList {
            val array = root.optJSONArray("passwords") ?: JSONArray()
            for (i in 0 until array.length()) {
                val p = array.optJSONObject(i) ?: continue
                add(PasswordEntry(
                    id = p.optString("id").ifBlank { newId() },
                    title = p.optString("title"),
                    login = p.optString("login"),
                    password = p.optString("password"),
                    website = p.optString("website"),
                    note = p.optString("note")
                ))
            }
        }
        val links = buildList {
            val array = root.optJSONArray("links") ?: JSONArray()
            for (i in 0 until array.length()) {
                val link = array.optJSONObject(i) ?: continue
                add(SavedLink(
                    id = link.optString("id").ifBlank { newId() },
                    title = link.optString("title"),
                    url = link.optString("url"),
                    note = link.optString("note")
                ))
            }
        }
        val notes = buildList {
            val array = root.optJSONArray("notes") ?: JSONArray()
            for (i in 0 until array.length()) {
                val note = array.optJSONObject(i) ?: continue
                add(CalendarNote(
                    id = note.optString("id").ifBlank { newId() },
                    date = note.optString("date"),
                    title = note.optString("title"),
                    body = note.optString("body")
                ))
            }
        }
        return VaultData(passwords, links, notes)
    }
}

private fun newId(): String = java.util.UUID.randomUUID().toString()

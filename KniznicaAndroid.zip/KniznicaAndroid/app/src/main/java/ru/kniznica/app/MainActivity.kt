package ru.kniznica.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Forest = Color(0xFF176B5B)
private val ForestDark = Color(0xFF0E4D42)
private val Cream = Color(0xFFF7F8F4)
private val PaleGreen = Color(0xFFE1F0E9)
private val Ink = Color(0xFF1D2925)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        val store = VaultStore(applicationContext)
        setContent {
            KniznicaTheme {
                var activeSession by remember { mutableStateOf<VaultSession?>(null) }
                var vaultExists by remember { mutableStateOf(store.exists()) }
                val context = LocalContext.current

                if (activeSession == null) {
                    LockScreen(
                        vaultExists = vaultExists,
                        onUnlock = { password ->
                            try {
                                activeSession = store.unlock(password)
                                null
                            } catch (_: Exception) {
                                "Не удалось открыть хранилище. Проверьте мастер-пароль или целостность файла."
                            }
                        },
                        onCreate = { password ->
                            try {
                                activeSession = store.create(password)
                                vaultExists = true
                                null
                            } catch (e: Exception) {
                                "Не удалось создать хранилище: ${e.localizedMessage ?: "ошибка записи"}"
                            }
                        }
                    )
                } else {
                    val session = activeSession!!
                    VaultHome(
                        session = session,
                        onLock = { activeSession = null },
                        onCommit = { updated ->
                            try {
                                activeSession = store.save(session, updated)
                                true
                            } catch (e: Exception) {
                                Toast.makeText(
                                    context,
                                    "Не удалось сохранить изменения",
                                    Toast.LENGTH_LONG
                                ).show()
                                false
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun KniznicaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Forest,
            onPrimary = Color.White,
            secondary = ForestDark,
            background = Cream,
            surface = Color.White,
            surfaceVariant = PaleGreen,
            onSurface = Ink,
            onBackground = Ink,
            error = Color(0xFFB3261E)
        ),
        content = content
    )
}

@Composable
private fun LockScreen(
    vaultExists: Boolean,
    onUnlock: (String) -> String?,
    onCreate: (String) -> String?
) {
    var masterPassword by remember { mutableStateOf("") }
    var repeatPassword by remember { mutableStateOf("") }
    var revealPassword by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    Box(
        modifier = Modifier.fillMaxSize().background(Cream).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                modifier = Modifier.size(78.dp),
                shape = RoundedCornerShape(26.dp),
                color = PaleGreen
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Forest, modifier = Modifier.size(38.dp))
                }
            }
            Text("Записная книга", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = ForestDark)
            Text(
                if (vaultExists) "Введите мастер-пароль, чтобы открыть личное хранилище" else "Создайте мастер-пароль для защиты ваших записей",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 15.sp
            )
            OutlinedTextField(
                value = masterPassword,
                onValueChange = { masterPassword = it; error = "" },
                label = { Text("Мастер-пароль") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (revealPassword) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { revealPassword = !revealPassword }) {
                        Icon(
                            if (revealPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (revealPassword) "Скрыть" else "Показать"
                        )
                    }
                }
            )
            if (!vaultExists) {
                OutlinedTextField(
                    value = repeatPassword,
                    onValueChange = { repeatPassword = it; error = "" },
                    label = { Text("Повторите мастер-пароль") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation()
                )
                Text(
                    "Используйте не менее 8 символов. Пароль нельзя восстановить, поэтому сохраните его в надёжном месте.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (error.isNotBlank()) {
                Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Button(
                onClick = {
                    when {
                        masterPassword.isBlank() -> error = "Введите мастер-пароль."
                        vaultExists -> error = onUnlock(masterPassword).orEmpty()
                        masterPassword.length < 8 -> error = "Мастер-пароль должен содержать не менее 8 символов."
                        masterPassword != repeatPassword -> error = "Пароли не совпадают."
                        else -> error = onCreate(masterPassword).orEmpty()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(if (vaultExists) "Открыть хранилище" else "Создать хранилище", fontSize = 16.sp)
            }
            Text("Данные хранятся только на этом устройстве и зашифрованы.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private enum class VaultTab(val label: String) {
    PASSWORDS("Пароли"), LINKS("Ссылки"), CALENDAR("Календарь")
}

@Composable
private fun VaultHome(
    session: VaultSession,
    onLock: () -> Unit,
    onCommit: (VaultData) -> Boolean
) {
    var selectedTab by rememberSaveable { mutableStateOf(VaultTab.PASSWORDS.name) }
    Column(modifier = Modifier.fillMaxSize().background(Cream)) {
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White).padding(start = 18.dp, end = 10.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Записная книга", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ForestDark)
                Text("Личное хранилище · зашифровано", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onLock) {
                Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(5.dp))
                Text("Закрыть")
            }
        }
        Divider(color = PaleGreen)
        when (VaultTab.valueOf(selectedTab)) {
            VaultTab.PASSWORDS -> PasswordsScreen(session.data, onCommit)
            VaultTab.LINKS -> LinksScreen(session.data, onCommit)
            VaultTab.CALENDAR -> CalendarScreen(session.data, onCommit)
        }
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            VaultTab.values().forEach { tab ->
                val active = selectedTab == tab.name
                Surface(
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable { selectedTab = tab.name },
                    shape = RoundedCornerShape(14.dp),
                    color = if (active) PaleGreen else Color.Transparent
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            when (tab) {
                                VaultTab.PASSWORDS -> "🔐"
                                VaultTab.LINKS -> "🔗"
                                VaultTab.CALENDAR -> "📅"
                            },
                            fontSize = 19.sp
                        )
                        Text(tab.label, fontSize = 12.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, color = if (active) ForestDark else Ink)
                    }
                }
            }
        }
    }
}

@Composable
private fun PasswordsScreen(data: VaultData, onCommit: (VaultData) -> Boolean) {
    var search by rememberSaveable { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<PasswordEntry?>(null) }
    var deleteTarget by remember { mutableStateOf<PasswordEntry?>(null) }
    val filtered = remember(data.passwords, search) {
        data.passwords.filter { listOf(it.title, it.login, it.website, it.note).any { value -> value.contains(search, true) } }
            .sortedBy { it.title.lowercase(Locale.getDefault()) }
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Пароли", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Записей: ${data.passwords.size}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
            Button(onClick = { editing = null; showEditor = true }) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Добавить")
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            label = { Text("Поиск по паролям") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) {
            EmptyState(
                title = if (search.isBlank()) "Пока нет паролей" else "Ничего не найдено",
                subtitle = if (search.isBlank()) "Добавьте первую запись, чтобы сохранить логин и пароль." else "Попробуйте изменить запрос."
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
                items(filtered, key = { it.id }) { entry ->
                    PasswordCard(
                        entry = entry,
                        onEdit = { editing = entry; showEditor = true },
                        onDelete = { deleteTarget = entry }
                    )
                }
            }
        }
    }

    if (showEditor) {
        PasswordEditor(
            initial = editing,
            onDismiss = { showEditor = false },
            onSave = { item ->
                val updatedList = if (editing == null) data.passwords + item else data.passwords.map { if (it.id == item.id) item else it }
                if (onCommit(data.copy(passwords = updatedList))) showEditor = false
            }
        )
    }
    deleteTarget?.let { target ->
        ConfirmDeleteDialog(
            title = "Удалить пароль?",
            message = "Запись «${target.title}» будет удалена без возможности отмены.",
            onCancel = { deleteTarget = null },
            onConfirm = {
                if (onCommit(data.copy(passwords = data.passwords.filterNot { it.id == target.id }))) deleteTarget = null
            }
        )
    }
}

@Composable
private fun PasswordCard(entry: PasswordEntry, onEdit: () -> Unit, onDelete: () -> Unit) {
    var revealed by rememberSaveable(entry.id) { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(entry.title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = ForestDark)
            if (entry.login.isNotBlank()) Text("Логин: ${entry.login}", fontSize = 14.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Пароль: ${if (revealed) entry.password.ifBlank { "—" } else if (entry.password.isBlank()) "—" else "••••••••"}",
                    modifier = Modifier.weight(1f),
                    fontSize = 14.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                IconButton(onClick = { revealed = !revealed }) {
                    Icon(if (revealed) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = if (revealed) "Скрыть пароль" else "Показать пароль")
                }
                IconButton(onClick = {
                    if (entry.password.isNotEmpty()) {
                        clipboard.setText(AnnotatedString(entry.password))
                        Toast.makeText(context, "Пароль скопирован", Toast.LENGTH_SHORT).show()
                    }
                }) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Копировать пароль")
                }
            }
            if (entry.website.isNotBlank()) Text("Сайт: ${entry.website}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (entry.note.isNotBlank()) Text(entry.note, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Изменить") }
                TextButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Удалить") }
            }
        }
    }
}

@Composable
private fun PasswordEditor(initial: PasswordEntry?, onDismiss: () -> Unit, onSave: (PasswordEntry) -> Unit) {
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var login by remember { mutableStateOf(initial?.login.orEmpty()) }
    var password by remember { mutableStateOf(initial?.password.orEmpty()) }
    var website by remember { mutableStateOf(initial?.website.orEmpty()) }
    var note by remember { mutableStateOf(initial?.note.orEmpty()) }
    var reveal by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Новый пароль" else "Изменить пароль") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 480.dp)) {
                OutlinedTextField(title, { title = it; error = "" }, label = { Text("Название *") }, singleLine = true)
                OutlinedTextField(login, { login = it }, label = { Text("Логин / почта") }, singleLine = true)
                OutlinedTextField(
                    password, { password = it }, label = { Text("Пароль") }, singleLine = true,
                    visualTransformation = if (reveal) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { IconButton(onClick = { reveal = !reveal }) { Icon(if (reveal) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null) } }
                )
                OutlinedTextField(website, { website = it }, label = { Text("Сайт") }, singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("Комментарий") }, minLines = 2, maxLines = 4)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.isBlank()) error = "Укажите название записи."
                else onSave(PasswordEntry(initial?.id ?: java.util.UUID.randomUUID().toString(), title.trim(), login.trim(), password, website.trim(), note.trim()))
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun LinksScreen(data: VaultData, onCommit: (VaultData) -> Boolean) {
    var search by rememberSaveable { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<SavedLink?>(null) }
    var deleteTarget by remember { mutableStateOf<SavedLink?>(null) }
    val filtered = remember(data.links, search) {
        data.links.filter { listOf(it.title, it.url, it.note).any { value -> value.contains(search, true) } }
            .sortedBy { it.title.lowercase(Locale.getDefault()) }
    }
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Сохранённые ссылки", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Записей: ${data.links.size}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
            Button(onClick = { editing = null; showEditor = true }) {
                Icon(Icons.Default.Add, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("Добавить")
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(search, { search = it }, label = { Text("Поиск по ссылкам") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) {
            EmptyState(if (search.isBlank()) "Ссылок пока нет" else "Ничего не найдено", "Сохраняйте полезные страницы, статьи и адреса сайтов.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
                items(filtered, key = { it.id }) { link ->
                    LinkCard(link, onEdit = { editing = link; showEditor = true }, onDelete = { deleteTarget = link })
                }
            }
        }
    }
    if (showEditor) {
        LinkEditor(initial = editing, onDismiss = { showEditor = false }, onSave = { item ->
            val updated = if (editing == null) data.links + item else data.links.map { if (it.id == item.id) item else it }
            if (onCommit(data.copy(links = updated))) showEditor = false
        })
    }
    deleteTarget?.let { target ->
        ConfirmDeleteDialog("Удалить ссылку?", "Запись «${target.title}» будет удалена.", onCancel = { deleteTarget = null }, onConfirm = {
            if (onCommit(data.copy(links = data.links.filterNot { it.id == target.id }))) deleteTarget = null
        })
    }
}

@Composable
private fun LinkCard(link: SavedLink, onEdit: () -> Unit, onDelete: () -> Unit) {
    val context = LocalContext.current
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(link.title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = ForestDark)
            Text(link.url, color = Forest, fontSize = 13.sp)
            if (link.note.isNotBlank()) Text(link.note, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { openWebAddress(context, link.url) }) { Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Открыть") }
                TextButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Изменить") }
                TextButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Удалить") }
            }
        }
    }
}

@Composable
private fun LinkEditor(initial: SavedLink?, onDismiss: () -> Unit, onSave: (SavedLink) -> Unit) {
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var url by remember { mutableStateOf(initial?.url.orEmpty()) }
    var note by remember { mutableStateOf(initial?.note.orEmpty()) }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Новая ссылка" else "Изменить ссылку") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it; error = "" }, label = { Text("Название *") }, singleLine = true)
                OutlinedTextField(url, { url = it; error = "" }, label = { Text("Адрес сайта *") }, singleLine = false, maxLines = 2)
                OutlinedTextField(note, { note = it }, label = { Text("Описание / заметка") }, minLines = 2, maxLines = 4)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                val normalized = normalizeWebAddress(url)
                when {
                    title.isBlank() -> error = "Укажите название ссылки."
                    normalized == null -> error = "Введите корректный адрес сайта."
                    else -> onSave(SavedLink(initial?.id ?: java.util.UUID.randomUUID().toString(), title.trim(), normalized, note.trim()))
                }
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun CalendarScreen(data: VaultData, onCommit: (VaultData) -> Boolean) {
    var displayedMonth by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<CalendarNote?>(null) }
    var deleteTarget by remember { mutableStateOf<CalendarNote?>(null) }
    val selectedKey = selectedDate.toString()
    val todaysNotes = remember(data.notes, selectedKey) { data.notes.filter { it.date == selectedKey }.sortedBy { it.title.lowercase(Locale.getDefault()) } }
    val monthLabel = remember(displayedMonth) { displayedMonth.format(DateTimeFormatter.ofPattern("LLLL yyyy", Locale("ru"))).replaceFirstChar { it.titlecase(Locale("ru")) } }
    val weekdayLabels = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    val startOffset = displayedMonth.atDay(1).dayOfWeek.value - 1
    val cellCount = startOffset + displayedMonth.lengthOfMonth()

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
        Text("Заметки по календарю", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = { val next = displayedMonth.minusMonths(1); displayedMonth = next; selectedDate = next.atDay(1) }) { Icon(Icons.Default.ChevronLeft, contentDescription = "Предыдущий месяц") }
            Text(monthLabel, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            IconButton(onClick = { val next = displayedMonth.plusMonths(1); displayedMonth = next; selectedDate = next.atDay(1) }) { Icon(Icons.Default.ChevronRight, contentDescription = "Следующий месяц") }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            weekdayLabels.forEach { label ->
                Box(modifier = Modifier.weight(1f).padding(vertical = 3.dp), contentAlignment = Alignment.Center) {
                    Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            modifier = Modifier.fillMaxWidth().height(330.dp),
            userScrollEnabled = false
        ) {
            items(cellCount) { index ->
                if (index < startOffset) {
                    Spacer(modifier = Modifier.padding(2.dp).aspectRatio(1f))
                } else {
                    val day = index - startOffset + 1
                    val date = displayedMonth.atDay(day)
                    val isSelected = date == selectedDate
                    val hasNotes = data.notes.any { it.date == date.toString() }
                    Surface(
                        onClick = { selectedDate = date },
                        modifier = Modifier.padding(2.dp).aspectRatio(1f),
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) Forest else if (hasNotes) PaleGreen else Color.White,
                        shadowElevation = if (isSelected) 2.dp else 0.dp
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text(day.toString(), color = if (isSelected) Color.White else Ink, fontSize = 14.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                            if (hasNotes) {
                                Box(modifier = Modifier.padding(top = 1.dp).size(4.dp).clip(CircleShape).background(if (isSelected) Color.White else Forest))
                            } else {
                                Spacer(Modifier.height(5.dp))
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(modifier = Modifier.weight(1f)) {
                Text(selectedDate.format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale("ru"))).replaceFirstChar { it.titlecase(Locale("ru")) }, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Заметок: ${todaysNotes.size}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = { editing = null; showEditor = true }) { Icon(Icons.Default.Add, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("Заметка") }
        }
        Spacer(Modifier.height(8.dp))
        if (todaysNotes.isEmpty()) {
            EmptyState("Нет заметок на этот день", "Выберите день в календаре и добавьте планы или напоминания.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                items(todaysNotes, key = { it.id }) { note ->
                    NoteCard(note, onEdit = { editing = note; showEditor = true }, onDelete = { deleteTarget = note })
                }
            }
        }
    }

    if (showEditor) {
        NoteEditor(initial = editing, date = selectedDate, onDismiss = { showEditor = false }, onSave = { note ->
            val updated = if (editing == null) data.notes + note else data.notes.map { if (it.id == note.id) note else it }
            if (onCommit(data.copy(notes = updated))) showEditor = false
        })
    }
    deleteTarget?.let { target ->
        ConfirmDeleteDialog("Удалить заметку?", "Заметка «${target.title}» будет удалена.", onCancel = { deleteTarget = null }, onConfirm = {
            if (onCommit(data.copy(notes = data.notes.filterNot { it.id == target.id }))) deleteTarget = null
        })
    }
}

@Composable
private fun NoteCard(note: CalendarNote, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(note.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = ForestDark)
            if (note.body.isNotBlank()) Text(note.body, fontSize = 14.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Изменить") }
                TextButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Удалить") }
            }
        }
    }
}

@Composable
private fun NoteEditor(initial: CalendarNote?, date: LocalDate, onDismiss: () -> Unit, onSave: (CalendarNote) -> Unit) {
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var body by remember { mutableStateOf(initial?.body.orEmpty()) }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Новая заметка" else "Изменить заметку") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Дата: ${date.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(title, { title = it; error = "" }, label = { Text("Заголовок *") }, singleLine = true)
                OutlinedTextField(body, { body = it }, label = { Text("Текст заметки") }, minLines = 3, maxLines = 6)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.isBlank()) error = "Укажите заголовок заметки."
                else onSave(CalendarNote(initial?.id ?: java.util.UUID.randomUUID().toString(), initial?.date ?: date.toString(), title.trim(), body.trim()))
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, color = ForestDark)
        Text(subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ConfirmDeleteDialog(title: String, message: String, onCancel: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Удалить", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Отмена") } }
    )
}

private fun normalizeWebAddress(raw: String): String? {
    val trimmed = raw.trim()
    if (trimmed.isBlank()) return null
    val candidate = if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) trimmed else "https://$trimmed"
    val uri = runCatching { Uri.parse(candidate) }.getOrNull() ?: return null
    if ((uri.scheme.equals("https", true) || uri.scheme.equals("http", true)) && !uri.host.isNullOrBlank()) return uri.toString()
    return null
}

private fun openWebAddress(context: android.content.Context, raw: String) {
    val normalized = normalizeWebAddress(raw) ?: run {
        Toast.makeText(context, "Некорректный адрес сайта", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(normalized)))
    } catch (_: Exception) {
        Toast.makeText(context, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show()
    }
}
